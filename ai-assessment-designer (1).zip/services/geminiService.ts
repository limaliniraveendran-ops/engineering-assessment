
import { GoogleGenAI, Type } from "@google/genai";
import type { UserSelections, AssessmentPlan } from '../types';

if (!process.env.API_KEY) {
    throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export async function generateAssessmentOptions(selections: UserSelections): Promise<string[]> {
    const { field, level, clos } = selections;
    const filledCLOs = clos.filter(clo => clo.trim() !== '').join('; ');

    const prompt = `You are an expert curriculum designer for university-level engineering programs.
    Given the field of study '${field}', student level '${level}', and the following course learning outcomes: '${filledCLOs}',
    suggest exactly three distinct and creative assessment types suitable for this context.
    The suggestions should be practical and align with modern engineering education principles.`;

    const response = await ai.models.generateContent({
        model: "gemini-2.5-flash",
        contents: prompt,
        config: {
            responseMimeType: "application/json",
            responseSchema: {
                type: Type.OBJECT,
                properties: {
                    assessments: {
                        type: Type.ARRAY,
                        items: {
                            type: Type.STRING
                        },
                        description: "An array of three distinct assessment type suggestions."
                    }
                }
            }
        }
    });
    
    const jsonResponse = JSON.parse(response.text);
    return jsonResponse.assessments;
}

export async function generateDetailedPlan(selections: UserSelections, assessmentType: string): Promise<AssessmentPlan> {
    const { field, level, clos } = selections;
    const filledCLOs = clos.filter(clo => clo.trim() !== '').join('; ');

    const prompt = `You are an expert curriculum designer for university-level engineering programs, with a fun and encouraging tone.
    Based on the field '${field}', level '${level}', CLOs '${filledCLOs}', and the chosen assessment type '${assessmentType}',
    generate a detailed plan for a lecturer. The plan must include:
    1. A creative and engaging title for the assessment.
    2. A brief, compelling description of the assessment.
    3. A step-by-step guide on how the lecturer can design and structure this assessment.
    4. A list of helpful and practical tips for successful implementation and grading.
    5. A list of 2-3 specific AI tools that could help either the lecturer in creating the assessment or the student in completing it, with a brief explanation for each tool.`;

    const response = await ai.models.generateContent({
        model: "gemini-2.5-flash",
        contents: prompt,
        config: {
            responseMimeType: "application/json",
            responseSchema: {
                type: Type.OBJECT,
                properties: {
                    title: { type: Type.STRING, description: "A creative title for the assessment." },
                    description: { type: Type.STRING, description: "A brief description of the assessment." },
                    designSteps: {
                        type: Type.ARRAY,
                        items: { type: Type.STRING },
                        description: "A step-by-step guide for designing the assessment."
                    },
                    tips: {
                        type: Type.ARRAY,
                        items: { type: Type.STRING },
                        description: "A list of helpful tips for implementation."
                    },
                    suggestedAiTools: {
                        type: Type.ARRAY,
                        description: "A list of 2-3 AI tools with their name and a brief description of their use case for this assessment.",
                        items: {
                            type: Type.OBJECT,
                            properties: {
                                toolName: {
                                    type: Type.STRING,
                                    description: "The name of the AI tool."
                                },
                                description: {
                                    type: Type.STRING,
                                    description: "A brief explanation of how the tool can be used."
                                }
                            }
                        }
                    }
                }
            }
        }
    });

    return JSON.parse(response.text);
}
