
import React from 'react';
import CustomButton from './CustomButton';

interface ErrorDisplayProps {
  message: string;
  onRetry: () => void;
  onBack: () => void;
}

const ErrorDisplay: React.FC<ErrorDisplayProps> = ({ message, onRetry, onBack }) => (
  <div className="flex flex-col items-center justify-center py-20 text-center text-red-600 bg-red-50 rounded-lg">
    <svg xmlns="http://www.w3.org/2000/svg" className="h-16 w-16" fill="none" viewBox="0 0 24 24" stroke="currentColor">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
    </svg>
    <h3 className="mt-4 text-xl font-bold">Oops! Something went wrong.</h3>
    <p className="mt-2 text-red-500">{message}</p>
    <div className="mt-8 flex gap-4">
        <CustomButton onClick={onBack} variant="secondary">
            Go Back
        </CustomButton>
        <CustomButton onClick={onRetry}>
            Try Again
        </CustomButton>
    </div>
  </div>
);

export default ErrorDisplay;
