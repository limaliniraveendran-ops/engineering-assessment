
import React from 'react';
import type { UserSelections } from '../../types';
import CustomButton from '../CustomButton';

interface Props {
  selections: UserSelections;
  onUpdate: (updates: Partial<UserSelections>) => void;
  onNext: () => void;
  onBack: () => void;
}

const levels = ['Undergraduate Year 1', 'Undergraduate Year 2', 'Undergraduate Year 3'];

const Step2Level: React.FC<Props> = ({ selections, onUpdate, onNext, onBack }) => {
    return (
        <div className="animate-fade-in">
            <h2 className="text-2xl font-bold text-gray-800">Select Student Level</h2>
            <p className="mt-2 text-gray-600">Specify the academic year of the students.</p>
            <div className="mt-6 space-y-4">
                {levels.map(level => (
                    <button
                        key={level}
                        onClick={() => onUpdate({ level })}
                        className={`w-full p-4 rounded-lg text-left transition-all duration-200 border-2 ${selections.level === level ? 'bg-teal-50 border-teal-500 ring-2 ring-teal-500' : 'bg-white border-gray-200 hover:border-teal-400'}`}
                    >
                         <span className="font-semibold text-gray-700">{level}</span>
                    </button>
                ))}
            </div>
            <div className="mt-8 flex justify-between">
                <CustomButton onClick={onBack} variant="secondary">
                    Back
                </CustomButton>
                <CustomButton onClick={onNext} disabled={!selections.level}>
                    Next
                </CustomButton>
            </div>
        </div>
    );
};

export default Step2Level;
