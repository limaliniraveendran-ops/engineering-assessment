
import React from 'react';
import CustomButton from '../CustomButton';

interface Props {
  options: string[];
  onSelect: (option: string) => void;
  onBack: () => void;
}

const Step4Options: React.FC<Props> = ({ options, onSelect, onBack }) => {
    return (
        <div className="animate-fade-in">
            <h2 className="text-2xl font-bold text-gray-800">Choose an Assessment Type</h2>
            <p className="mt-2 text-gray-600">Our AI has generated these options for you. Select one to see a detailed plan.</p>
            <div className="mt-6 space-y-4">
                {options.map((option, index) => (
                    <div
                        key={index}
                        onClick={() => onSelect(option)}
                        className="group p-5 rounded-lg border-2 border-gray-200 hover:border-teal-500 hover:bg-teal-50 cursor-pointer transition-all"
                    >
                        <h3 className="text-lg font-semibold text-teal-700 group-hover:text-teal-800">{option}</h3>
                    </div>
                ))}
            </div>
            <div className="mt-8 flex justify-between">
                <CustomButton onClick={onBack} variant="secondary">
                    Back
                </CustomButton>
            </div>
        </div>
    );
};

export default Step4Options;
