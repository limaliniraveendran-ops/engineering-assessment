
import React from 'react';
import type { AssessmentPlan } from '../../types';
import CustomButton from '../CustomButton';

interface Props {
  plan: AssessmentPlan | null;
  onReset: () => void;
}

const Step5Plan: React.FC<Props> = ({ plan, onReset }) => {
    if (!plan) {
        return (
            <div className="text-center py-10">
                <p className="text-gray-600">No plan generated. Please start over.</p>
                <div className="mt-6">
                    <CustomButton onClick={onReset}>Start Over</CustomButton>
                </div>
            </div>
        );
    }
    
    const { title, description, designSteps, tips, suggestedAiTools } = plan;

    return (
        <div className="animate-fade-in space-y-8">
            <div>
                <h2 className="text-3xl font-bold text-teal-600">{title}</h2>
                <p className="mt-2 text-gray-700">{description}</p>
            </div>

            <div className="p-6 bg-gray-50 rounded-lg">
                <h3 className="text-xl font-semibold text-gray-800">Design Steps</h3>
                <ul className="mt-4 list-decimal list-inside space-y-2 text-gray-600">
                    {designSteps.map((step, index) => (
                        <li key={index}>{step}</li>
                    ))}
                </ul>
            </div>
            
            <div className="p-6 bg-amber-50 rounded-lg">
                <h3 className="text-xl font-semibold text-amber-800">Helpful Tips ✨</h3>
                 <ul className="mt-4 list-disc list-inside space-y-2 text-amber-700">
                    {tips.map((tip, index) => (
                        <li key={index}>{tip}</li>
                    ))}
                </ul>
            </div>

            {suggestedAiTools && suggestedAiTools.length > 0 && (
                <div className="p-6 bg-slate-50 rounded-lg">
                    <h3 className="text-xl font-semibold text-slate-800">🚀 Suggested AI Tools</h3>
                    <ul className="mt-4 space-y-4 text-slate-700">
                        {suggestedAiTools.map((tool, index) => (
                            <li key={index}>
                                <strong className="font-semibold text-slate-900">{tool.toolName}:</strong> {tool.description}
                            </li>
                        ))}
                    </ul>
                </div>
            )}

            <div className="mt-10 text-center">
                <CustomButton onClick={onReset}>
                    Design Another Assessment
                </CustomButton>
            </div>
        </div>
    );
};

export default Step5Plan;
