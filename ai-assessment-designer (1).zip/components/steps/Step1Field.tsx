
import React from 'react';
import type { UserSelections } from '../../types';
import CustomButton from '../CustomButton';

interface Props {
  selections: UserSelections;
  onUpdate: (updates: Partial<UserSelections>) => void;
  onNext: () => void;
}

const fields = [
    'Chemical Engineering',
    'Petroleum Engineering',
    'Electrical Engineering',
    'Mechanical Engineering',
    'Integrated Engineering'
];

const Step1Field: React.FC<Props> = ({ selections, onUpdate, onNext }) => {
    return (
        <div className="animate-fade-in">
            <h2 className="text-2xl font-bold text-gray-800">Select Field of Study</h2>
            <p className="mt-2 text-gray-600">Choose the engineering discipline for this assessment.</p>
            <div className="mt-6 grid grid-cols-1 sm:grid-cols-2 gap-4">
                {fields.map(field => (
                    <button
                        key={field}
                        onClick={() => onUpdate({ field })}
                        className={`p-4 rounded-lg text-left transition-all duration-200 border-2 ${selections.field === field ? 'bg-teal-50 border-teal-500 ring-2 ring-teal-500' : 'bg-white border-gray-200 hover:border-teal-400'}`}
                    >
                        <span className="font-semibold text-gray-700">{field}</span>
                    </button>
                ))}
            </div>
            <div className="mt-8 text-right">
                <CustomButton onClick={onNext} disabled={!selections.field}>
                    Next
                </CustomButton>
            </div>
        </div>
    );
};

export default Step1Field;
