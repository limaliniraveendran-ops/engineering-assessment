
import React from 'react';
import type { UserSelections } from '../../types';
import CustomButton from '../CustomButton';

interface Props {
  selections: UserSelections;
  onUpdate: (updates: Partial<UserSelections>) => void;
  onNext: () => void;
  onBack: () => void;
}

const Step3CLO: React.FC<Props> = ({ selections, onUpdate, onNext, onBack }) => {
    const handleCloChange = (index: number, value: string) => {
        const newClos = [...selections.clos];
        newClos[index] = value;
        onUpdate({ clos: newClos });
    };

    const isNextDisabled = selections.clos.every(clo => clo.trim() === '');

    return (
        <div className="animate-fade-in">
            <h2 className="text-2xl font-bold text-gray-800">Enter Course Learning Outcomes (CLOs)</h2>
            <p className="mt-2 text-gray-600">Provide up to 3 CLOs. The AI will use these to tailor suggestions. (At least one is required)</p>
            <div className="mt-6 space-y-4">
                {[0, 1, 2].map(index => (
                    <div key={index}>
                        <label htmlFor={`clo-${index}`} className="block text-sm font-medium text-gray-700">
                            CLO {index + 1}
                        </label>
                        <textarea
                            id={`clo-${index}`}
                            rows={2}
                            value={selections.clos[index]}
                            onChange={(e) => handleCloChange(index, e.target.value)}
                            placeholder={`e.g., "Analyze complex circuits using Kirchhoff's laws"`}
                            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-teal-500 focus:ring-teal-500 sm:text-sm"
                        />
                    </div>
                ))}
            </div>
            <div className="mt-8 flex justify-between">
                <CustomButton onClick={onBack} variant="secondary">
                    Back
                </CustomButton>
                <CustomButton onClick={onNext} disabled={isNextDisabled}>
                    Generate Options
                </CustomButton>
            </div>
        </div>
    );
};

export default Step3CLO;
