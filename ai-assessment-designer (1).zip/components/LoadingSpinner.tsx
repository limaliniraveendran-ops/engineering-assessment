
import React from 'react';

interface LoadingSpinnerProps {
    message?: string;
}

const LoadingSpinner: React.FC<LoadingSpinnerProps> = ({ message = "Loading..." }) => (
    <div className="flex flex-col items-center justify-center py-20 text-center">
        <div className="w-16 h-16 border-4 border-dashed rounded-full animate-spin border-teal-500"></div>
        <p className="mt-4 text-lg font-semibold text-gray-700">{message}</p>
        <p className="mt-2 text-sm text-gray-500">Our AI is thinking... this may take a moment.</p>
    </div>
);

export default LoadingSpinner;
